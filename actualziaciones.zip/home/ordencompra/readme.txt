Tabla: ordenventa // esto es una tabla para llenar una orden de venta que es en si un presupuesto aprovado
codigosap
proyecto
direccion_proyecto
observacion
fecha


tabla: items_orden_venta // aqui debemos porner los items persupuestados par ala orden de venta
pero debemos poner una llave aquipara referenciarlos 

nro_articulo
cantidad
precio_bruto
total_bruto


por ejemplo tenemos 40 articulos pero deben ser de una sola orden de venta estonces como hacemos?